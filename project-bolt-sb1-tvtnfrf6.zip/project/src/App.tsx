import React, { useState } from 'react';
import { Book, Wand2, Image, Download, Plus, Edit3, Eye, Settings } from 'lucide-react';
import StoryGenerator from './components/StoryGenerator';
import StoryEditor from './components/StoryEditor';
import BookPreview from './components/BookPreview';
import IllustrationManager from './components/IllustrationManager';

interface StoryPage {
  id: string;
  pageNumber: number;
  storyText: string;
  illustrationPrompt: string;
  imageUrl?: string;
}

interface StoryData {
  title: string;
  pages: StoryPage[];
  theme: string;
  mainCharacter: string;
  ageGroup: string;
}

type ViewMode = 'generate' | 'edit' | 'illustrate' | 'preview';

function App() {
  const [currentView, setCurrentView] = useState<ViewMode>('generate');
  const [storyData, setStoryData] = useState<StoryData | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleStoryGenerated = (story: StoryData) => {
    setStoryData(story);
    setCurrentView('edit');
  };

  const handleStoryUpdated = (updatedStory: StoryData) => {
    setStoryData(updatedStory);
  };

  const navigationItems = [
    { id: 'generate', icon: Wand2, label: 'Generate', color: 'bg-coral-500' },
    { id: 'edit', icon: Edit3, label: 'Edit Story', color: 'bg-mint-500', disabled: !storyData },
    { id: 'illustrate', icon: Image, label: 'Illustrations', color: 'bg-yellow-500', disabled: !storyData },
    { id: 'preview', icon: Eye, label: 'Preview', color: 'bg-purple-500', disabled: !storyData },
  ];

  const renderCurrentView = () => {
    switch (currentView) {
      case 'generate':
        return <StoryGenerator onStoryGenerated={handleStoryGenerated} isGenerating={isGenerating} setIsGenerating={setIsGenerating} />;
      case 'edit':
        return storyData ? <StoryEditor storyData={storyData} onStoryUpdated={handleStoryUpdated} /> : null;
      case 'illustrate':
        return storyData ? <IllustrationManager storyData={storyData} onStoryUpdated={handleStoryUpdated} /> : null;
      case 'preview':
        return storyData ? <BookPreview storyData={storyData} /> : null;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-blue-50 to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-white/20 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-coral-500 to-pink-500 p-2 rounded-xl">
                <Book className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Storybook Illustrator</h1>
                <p className="text-sm text-gray-500">Create magical children's books</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-coral-500 to-pink-500 text-white rounded-full hover:shadow-lg transition-all duration-200 transform hover:scale-105">
                <Download className="w-4 h-4" />
                <span className="hidden sm:inline">Export</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation */}
        <nav className="flex flex-wrap gap-4 mb-8">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            const isDisabled = item.disabled;

            return (
              <button
                key={item.id}
                onClick={() => !isDisabled && setCurrentView(item.id as ViewMode)}
                disabled={isDisabled}
                className={`flex items-center space-x-2 px-6 py-3 rounded-2xl font-medium transition-all duration-200 transform hover:scale-105 ${
                  isActive
                    ? `${item.color} text-white shadow-lg`
                    : isDisabled
                    ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    : 'bg-white text-gray-700 hover:bg-gray-50 shadow-md hover:shadow-lg'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Main Content */}
        <main className="bg-white rounded-3xl shadow-xl p-8 min-h-[600px]">
          {renderCurrentView()}
        </main>
      </div>
    </div>
  );
}

export default App;