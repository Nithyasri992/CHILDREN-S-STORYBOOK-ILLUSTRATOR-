import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Download, Share2, Book, Printer as Print } from 'lucide-react';

interface StoryPage {
  id: string;
  pageNumber: number;
  storyText: string;
  illustrationPrompt: string;
  imageUrl?: string;
}

interface StoryData {
  title: string;
  pages: StoryPage[];
  theme: string;
  mainCharacter: string;
  ageGroup: string;
}

interface BookPreviewProps {
  storyData: StoryData;
}

const BookPreview: React.FC<BookPreviewProps> = ({ storyData }) => {
  const [currentPage, setCurrentPage] = useState(0); // 0 for cover, 1+ for story pages
  const [isFlipping, setIsFlipping] = useState(false);

  const totalPages = storyData.pages.length + 1; // +1 for cover

  const nextPage = () => {
    if (currentPage < totalPages - 1) {
      setIsFlipping(true);
      setTimeout(() => {
        setCurrentPage(currentPage + 1);
        setIsFlipping(false);
      }, 300);
    }
  };

  const prevPage = () => {
    if (currentPage > 0) {
      setIsFlipping(true);
      setTimeout(() => {
        setCurrentPage(currentPage - 1);
        setIsFlipping(false);
      }, 300);
    }
  };

  const goToPage = (pageIndex: number) => {
    if (pageIndex !== currentPage) {
      setIsFlipping(true);
      setTimeout(() => {
        setCurrentPage(pageIndex);
        setIsFlipping(false);
      }, 300);
    }
  };

  const renderCover = () => (
    <div className="h-full bg-gradient-to-br from-coral-400 via-pink-400 to-purple-400 text-white flex flex-col items-center justify-center p-8 text-center">
      <div className="bg-white/20 backdrop-blur-sm rounded-3xl p-8 max-w-md">
        <Book className="w-16 h-16 mx-auto mb-6 opacity-90" />
        <h1 className="text-3xl font-bold mb-4 leading-tight">{storyData.title}</h1>
        <div className="text-lg opacity-90 mb-6">A Story About {storyData.theme}</div>
        <div className="text-sm opacity-75">Ages {storyData.ageGroup}</div>
      </div>
      <div className="mt-8 text-center">
        <div className="text-sm opacity-75 mb-2">Featuring</div>
        <div className="text-xl font-semibold">{storyData.mainCharacter}</div>
      </div>
    </div>
  );

  const renderPage = (page: StoryPage) => (
    <div className="h-full bg-white flex">
      {/* Illustration Side */}
      <div className="w-1/2 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-8">
        {page.imageUrl ? (
          <img
            src={page.imageUrl}
            alt={`Illustration for page ${page.pageNumber}`}
            className="max-w-full max-h-full object-contain rounded-xl shadow-lg"
          />
        ) : (
          <div className="text-center">
            <div className="w-32 h-32 bg-gray-200 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Book className="w-12 h-12 text-gray-400" />
            </div>
            <p className="text-gray-500">Illustration will appear here</p>
          </div>
        )}
      </div>
      
      {/* Text Side */}
      <div className="w-1/2 p-8 flex flex-col justify-center">
        <div className="max-w-sm mx-auto">
          <div className="text-lg leading-relaxed text-gray-800 font-medium">
            {page.storyText}
          </div>
          <div className="mt-8 text-center">
            <div className="text-sm text-gray-400">Page {page.pageNumber}</div>
          </div>
        </div>
      </div>
    </div>
  );

  const currentStoryPage = currentPage > 0 ? storyData.pages[currentPage - 1] : null;

  return (
    <div className="max-w-7xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Book Preview</h2>
        <p className="text-lg text-gray-600">See how your story will look as a finished book</p>
      </div>

      {/* Book Container */}
      <div className="bg-white rounded-3xl shadow-2xl p-4 mb-8">
        <div 
          className={`aspect-[4/3] max-w-4xl mx-auto bg-white rounded-2xl shadow-inner overflow-hidden transition-all duration-300 ${
            isFlipping ? 'scale-98 opacity-80' : 'scale-100 opacity-100'
          }`}
        >
          {currentPage === 0 ? renderCover() : currentStoryPage && renderPage(currentStoryPage)}
        </div>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-center space-x-6 mb-8">
        <button
          onClick={prevPage}
          disabled={currentPage === 0}
          className="flex items-center space-x-2 px-6 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
        >
          <ChevronLeft className="w-5 h-5" />
          <span>Previous</span>
        </button>

        <div className="flex items-center space-x-2">
          {Array.from({ length: totalPages }, (_, i) => (
            <button
              key={i}
              onClick={() => goToPage(i)}
              className={`w-3 h-3 rounded-full transition-all duration-200 ${
                currentPage === i
                  ? 'bg-coral-500'
                  : 'bg-gray-300 hover:bg-gray-400'
              }`}
              title={i === 0 ? 'Cover' : `Page ${i}`}
            />
          ))}
        </div>

        <button
          onClick={nextPage}
          disabled={currentPage === totalPages - 1}
          className="flex items-center space-x-2 px-6 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
        >
          <span>Next</span>
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Page Navigation */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-6 mb-8">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Quick Navigation</h3>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => goToPage(0)}
            className={`px-4 py-2 rounded-xl font-medium transition-all duration-200 ${
              currentPage === 0
                ? 'bg-coral-500 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            Cover
          </button>
          {storyData.pages.map((page, index) => (
            <button
              key={page.id}
              onClick={() => goToPage(index + 1)}
              className={`px-4 py-2 rounded-xl font-medium transition-all duration-200 ${
                currentPage === index + 1
                  ? 'bg-coral-500 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
            >
              Page {page.pageNumber}
            </button>
          ))}
        </div>
      </div>

      {/* Export Options */}
      <div className="bg-gradient-to-r from-green-50 to-mint-50 border-2 border-green-200 rounded-2xl p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Export Your Book</h3>
        <div className="flex flex-wrap gap-4">
          <button className="flex items-center space-x-2 px-6 py-3 bg-green-500 text-white rounded-xl hover:bg-green-600 transition-colors">
            <Download className="w-5 h-5" />
            <span>Download PDF</span>
          </button>
          <button className="flex items-center space-x-2 px-6 py-3 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-colors">
            <Print className="w-5 h-5" />
            <span>Print Version</span>
          </button>
          <button className="flex items-center space-x-2 px-6 py-3 bg-purple-500 text-white rounded-xl hover:bg-purple-600 transition-colors">
            <Share2 className="w-5 h-5" />
            <span>Share Online</span>
          </button>
        </div>
        <p className="text-sm text-gray-600 mt-4">
          Export your completed storybook in various formats for printing, sharing, or digital reading.
        </p>
      </div>
    </div>
  );
};

export default BookPreview;