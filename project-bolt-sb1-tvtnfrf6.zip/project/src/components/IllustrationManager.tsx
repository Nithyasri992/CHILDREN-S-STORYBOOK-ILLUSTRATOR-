import React, { useState } from 'react';
import { Image, Download, RefreshCw, Eye, Settings, Palette } from 'lucide-react';

interface StoryPage {
  id: string;
  pageNumber: number;
  storyText: string;
  illustrationPrompt: string;
  imageUrl?: string;
}

interface StoryData {
  title: string;
  pages: StoryPage[];
  theme: string;
  mainCharacter: string;
  ageGroup: string;
}

interface IllustrationManagerProps {
  storyData: StoryData;
  onStoryUpdated: (updatedStory: StoryData) => void;
}

const artStyles = [
  { id: 'watercolor', name: 'Watercolor', description: 'Soft, dreamy watercolor style' },
  { id: 'cartoon', name: 'Cartoon', description: 'Bold, colorful cartoon style' },
  { id: 'pastel', name: 'Pastel', description: 'Gentle pastel illustration' },
  { id: 'realistic', name: 'Realistic', description: 'Detailed, lifelike illustrations' },
];

const colorPalettes = [
  { id: 'warm', name: 'Warm', colors: ['#FF6B6B', '#FFE66D', '#FF8E53'], description: 'Cozy and inviting' },
  { id: 'cool', name: 'Cool', colors: ['#4ECDC4', '#45B7D1', '#96CEB4'], description: 'Calm and peaceful' },
  { id: 'magical', name: 'Magical', colors: ['#A8E6CF', '#FFB3BA', '#FFDFBA'], description: 'Whimsical and enchanting' },
  { id: 'nature', name: 'Nature', colors: ['#8FBC8F', '#F0E68C', '#DEB887'], description: 'Earthy and natural' },
];

const IllustrationManager: React.FC<IllustrationManagerProps> = ({ storyData, onStoryUpdated }) => {
  const [selectedStyle, setSelectedStyle] = useState('watercolor');
  const [selectedPalette, setSelectedPalette] = useState('warm');
  const [isGenerating, setIsGenerating] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState(false);

  // Mock image URLs for demonstration
  const mockImageUrls = [
    'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
    'https://images.pexels.com/photos/302804/pexels-photo-302804.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
    'https://images.pexels.com/photos/1496372/pexels-photo-1496372.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
    'https://images.pexels.com/photos/1108101/pexels-photo-1108101.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
    'https://images.pexels.com/photos/1108117/pexels-photo-1108117.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
  ];

  const generateIllustration = async (pageId: string) => {
    setIsGenerating(pageId);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const pageIndex = storyData.pages.findIndex(p => p.id === pageId);
    const mockUrl = mockImageUrls[pageIndex % mockImageUrls.length];
    
    const updatedStory = {
      ...storyData,
      pages: storyData.pages.map(page =>
        page.id === pageId ? { ...page, imageUrl: mockUrl } : page
      )
    };
    
    onStoryUpdated(updatedStory);
    setIsGenerating(null);
  };

  const generateAllIllustrations = async () => {
    for (let i = 0; i < storyData.pages.length; i++) {
      await generateIllustration(storyData.pages[i].id);
    }
  };

  const selectedStyleData = artStyles.find(s => s.id === selectedStyle);
  const selectedPaletteData = colorPalettes.find(p => p.id === selectedPalette);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Illustration Manager</h2>
        <p className="text-lg text-gray-600">Generate and customize illustrations for your story</p>
      </div>

      {/* Style Settings */}
      <div className="bg-gradient-to-r from-yellow-50 to-orange-50 border-2 border-yellow-200 rounded-2xl p-6 mb-8">
        <h3 className="text-xl font-bold text-gray-900 mb-6">Illustration Settings</h3>
        
        <div className="grid md:grid-cols-2 gap-6">
          {/* Art Style */}
          <div>
            <label className="block text-lg font-semibold text-gray-700 mb-4">Art Style</label>
            <div className="space-y-2">
              {artStyles.map((style) => (
                <button
                  key={style.id}
                  onClick={() => setSelectedStyle(style.id)}
                  className={`w-full p-3 text-left border-2 rounded-xl transition-all duration-200 ${
                    selectedStyle === style.id
                      ? 'border-yellow-400 bg-yellow-50'
                      : 'border-gray-200 hover:border-gray-300 bg-white'
                  }`}
                >
                  <div className="font-semibold text-gray-900">{style.name}</div>
                  <div className="text-sm text-gray-600">{style.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Color Palette */}
          <div>
            <label className="block text-lg font-semibold text-gray-700 mb-4">Color Palette</label>
            <div className="space-y-2">
              {colorPalettes.map((palette) => (
                <button
                  key={palette.id}
                  onClick={() => setSelectedPalette(palette.id)}
                  className={`w-full p-3 text-left border-2 rounded-xl transition-all duration-200 ${
                    selectedPalette === palette.id
                      ? 'border-yellow-400 bg-yellow-50'
                      : 'border-gray-200 hover:border-gray-300 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-semibold text-gray-900">{palette.name}</div>
                    <div className="flex space-x-1">
                      {palette.colors.map((color, index) => (
                        <div
                          key={index}
                          className="w-4 h-4 rounded-full"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="text-sm text-gray-600">{palette.description}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap gap-4">
          <button
            onClick={generateAllIllustrations}
            disabled={isGenerating !== null}
            className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-yellow-500 to-orange-500 text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-200 transform hover:scale-105 disabled:opacity-50"
          >
            <Image className="w-5 h-5" />
            <span>Generate All Illustrations</span>
          </button>
          
          <button
            onClick={() => setPreviewMode(!previewMode)}
            className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-semibold transition-all duration-200 ${
              previewMode
                ? 'bg-purple-500 text-white'
                : 'bg-white text-purple-500 border-2 border-purple-500'
            }`}
          >
            <Eye className="w-5 h-5" />
            <span>{previewMode ? 'Exit Preview' : 'Preview Mode'}</span>
          </button>
        </div>
      </div>

      {/* Pages Grid */}
      <div className={`grid gap-6 ${previewMode ? 'grid-cols-1 max-w-2xl mx-auto' : 'md:grid-cols-2'}`}>
        {storyData.pages.map((page) => (
          <div
            key={page.id}
            className={`bg-white border-2 border-gray-200 rounded-2xl overflow-hidden ${
              previewMode ? 'shadow-2xl' : 'shadow-md hover:shadow-lg transition-shadow'
            }`}
          >
            {/* Image Area */}
            <div className={`${previewMode ? 'h-96' : 'h-48'} bg-gradient-to-br from-gray-100 to-gray-200 relative flex items-center justify-center`}>
              {page.imageUrl ? (
                <img
                  src={page.imageUrl}
                  alt={`Illustration for page ${page.pageNumber}`}
                  className="w-full h-full object-cover"
                />
              ) : isGenerating === page.id ? (
                <div className="text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-500 mx-auto mb-4"></div>
                  <p className="text-gray-600 font-medium">Generating illustration...</p>
                </div>
              ) : (
                <div className="text-center p-6">
                  <Image className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500 mb-4">No illustration yet</p>
                  <button
                    onClick={() => generateIllustration(page.id)}
                    className="px-4 py-2 bg-yellow-500 text-white rounded-full hover:bg-yellow-600 transition-colors"
                  >
                    Generate Image
                  </button>
                </div>
              )}
              
              {page.imageUrl && (
                <div className="absolute top-2 right-2 flex space-x-2">
                  <button
                    onClick={() => generateIllustration(page.id)}
                    className="p-2 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors"
                    title="Regenerate"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>

            {/* Content */}
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-gray-900">Page {page.pageNumber}</h3>
                <div className="text-sm text-gray-500">
                  {selectedStyleData?.name} • {selectedPaletteData?.name}
                </div>
              </div>
              
              {previewMode ? (
                <div className="text-gray-800 leading-relaxed text-lg">
                  {page.storyText}
                </div>
              ) : (
                <>
                  <div className="text-gray-800 mb-4 leading-relaxed">
                    {page.storyText}
                  </div>
                  
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="text-sm font-semibold text-gray-700 mb-1">Illustration Prompt:</div>
                    <div className="text-sm text-gray-600">
                      {page.illustrationPrompt}
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default IllustrationManager;