import React, { useState } from 'react';
import { Edit3, Save, Plus, Trash2, Wand2 } from 'lucide-react';

interface StoryPage {
  id: string;
  pageNumber: number;
  storyText: string;
  illustrationPrompt: string;
  imageUrl?: string;
}

interface StoryData {
  title: string;
  pages: StoryPage[];
  theme: string;
  mainCharacter: string;
  ageGroup: string;
}

interface StoryEditorProps {
  storyData: StoryData;
  onStoryUpdated: (updatedStory: StoryData) => void;
}

const StoryEditor: React.FC<StoryEditorProps> = ({ storyData, onStoryUpdated }) => {
  const [editingStory, setEditingStory] = useState<StoryData>(storyData);
  const [activePageId, setActivePageId] = useState(storyData.pages[0]?.id || '');

  const handleTitleChange = (newTitle: string) => {
    const updated = { ...editingStory, title: newTitle };
    setEditingStory(updated);
    onStoryUpdated(updated);
  };

  const handlePageTextChange = (pageId: string, newText: string) => {
    const updated = {
      ...editingStory,
      pages: editingStory.pages.map(page =>
        page.id === pageId ? { ...page, storyText: newText } : page
      )
    };
    setEditingStory(updated);
    onStoryUpdated(updated);
  };

  const handleIllustrationPromptChange = (pageId: string, newPrompt: string) => {
    const updated = {
      ...editingStory,
      pages: editingStory.pages.map(page =>
        page.id === pageId ? { ...page, illustrationPrompt: newPrompt } : page
      )
    };
    setEditingStory(updated);
    onStoryUpdated(updated);
  };

  const addNewPage = () => {
    const newPage: StoryPage = {
      id: Date.now().toString(),
      pageNumber: editingStory.pages.length + 1,
      storyText: '',
      illustrationPrompt: ''
    };
    const updated = {
      ...editingStory,
      pages: [...editingStory.pages, newPage]
    };
    setEditingStory(updated);
    onStoryUpdated(updated);
    setActivePageId(newPage.id);
  };

  const deletePage = (pageId: string) => {
    if (editingStory.pages.length <= 1) return;
    
    const updated = {
      ...editingStory,
      pages: editingStory.pages.filter(page => page.id !== pageId).map((page, index) => ({
        ...page,
        pageNumber: index + 1
      }))
    };
    setEditingStory(updated);
    onStoryUpdated(updated);
    
    if (activePageId === pageId) {
      setActivePageId(updated.pages[0]?.id || '');
    }
  };

  const generateIllustrationPrompt = (storyText: string) => {
    // Simple prompt generation based on story text
    const baseStyle = "in a soft watercolor children's book style, warm and whimsical, child-friendly";
    const prompt = `Illustration of ${storyText.toLowerCase().slice(0, 100)}... ${baseStyle}`;
    return prompt;
  };

  const autoGeneratePrompt = (pageId: string) => {
    const page = editingStory.pages.find(p => p.id === pageId);
    if (page && page.storyText) {
      const generatedPrompt = generateIllustrationPrompt(page.storyText);
      handleIllustrationPromptChange(pageId, generatedPrompt);
    }
  };

  const activePage = editingStory.pages.find(page => page.id === activePageId);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Edit Your Story</h2>
        <p className="text-lg text-gray-600">Refine your story text and illustration prompts</p>
      </div>

      {/* Story Title */}
      <div className="bg-gradient-to-r from-mint-50 to-blue-50 p-6 rounded-2xl mb-8">
        <label className="block text-lg font-semibold text-gray-700 mb-4">Story Title</label>
        <input
          type="text"
          value={editingStory.title}
          onChange={(e) => handleTitleChange(e.target.value)}
          className="w-full p-4 text-xl font-bold border-2 border-gray-200 rounded-xl focus:border-mint-400 focus:outline-none"
          placeholder="Enter your story title..."
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Page Navigation */}
        <div className="lg:col-span-1">
          <div className="bg-white border-2 border-gray-200 rounded-2xl p-6 sticky top-24">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900">Pages</h3>
              <button
                onClick={addNewPage}
                className="p-2 bg-mint-500 text-white rounded-full hover:bg-mint-600 transition-colors"
                title="Add New Page"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
            
            <div className="space-y-2">
              {editingStory.pages.map((page) => (
                <div
                  key={page.id}
                  className={`p-3 rounded-xl cursor-pointer transition-all duration-200 flex items-center justify-between ${
                    activePageId === page.id
                      ? 'bg-mint-100 border-2 border-mint-400'
                      : 'bg-gray-50 hover:bg-gray-100'
                  }`}
                  onClick={() => setActivePageId(page.id)}
                >
                  <div>
                    <div className="font-semibold text-gray-900">Page {page.pageNumber}</div>
                    <div className="text-sm text-gray-500 truncate">
                      {page.storyText.slice(0, 30)}...
                    </div>
                  </div>
                  {editingStory.pages.length > 1 && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deletePage(page.id);
                      }}
                      className="text-red-500 hover:text-red-700 transition-colors"
                      title="Delete Page"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Page Editor */}
        <div className="lg:col-span-2">
          {activePage && (
            <div className="space-y-6">
              <div className="bg-white border-2 border-gray-200 rounded-2xl p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  Page {activePage.pageNumber}
                </h3>
                
                {/* Story Text */}
                <div className="mb-6">
                  <label className="block text-lg font-semibold text-gray-700 mb-3">
                    Story Text
                  </label>
                  <textarea
                    value={activePage.storyText}
                    onChange={(e) => handlePageTextChange(activePage.id, e.target.value)}
                    className="w-full p-4 border-2 border-gray-200 rounded-xl focus:border-mint-400 focus:outline-none resize-none"
                    rows={4}
                    placeholder="Write your story text for this page..."
                  />
                  <p className="text-sm text-gray-500 mt-2">
                    Keep it simple - 2-3 sentences work best for children's books
                  </p>
                </div>

                {/* Illustration Prompt */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <label className="text-lg font-semibold text-gray-700">
                      Illustration Prompt
                    </label>
                    <button
                      onClick={() => autoGeneratePrompt(activePage.id)}
                      className="flex items-center space-x-2 px-3 py-1 bg-yellow-500 text-white rounded-full text-sm hover:bg-yellow-600 transition-colors"
                    >
                      <Wand2 className="w-3 h-3" />
                      <span>Auto Generate</span>
                    </button>
                  </div>
                  <textarea
                    value={activePage.illustrationPrompt}
                    onChange={(e) => handleIllustrationPromptChange(activePage.id, e.target.value)}
                    className="w-full p-4 border-2 border-gray-200 rounded-xl focus:border-mint-400 focus:outline-none resize-none"
                    rows={3}
                    placeholder="Describe what the illustration should show..."
                  />
                  <p className="text-sm text-gray-500 mt-2">
                    Be descriptive but clear. Include style preferences, colors, and mood.
                  </p>
                </div>
              </div>

              {/* Preview Card */}
              <div className="bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200 rounded-2xl p-6">
                <h4 className="text-lg font-bold text-gray-900 mb-4">Preview</h4>
                <div className="bg-white rounded-xl p-4 shadow-sm">
                  <div className="text-sm font-semibold text-purple-600 mb-2">
                    Page {activePage.pageNumber}
                  </div>
                  <div className="text-gray-800 mb-4 leading-relaxed">
                    {activePage.storyText || (
                      <span className="text-gray-400 italic">Story text will appear here...</span>
                    )}
                  </div>
                  <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded">
                    <strong>Illustration:</strong> {activePage.illustrationPrompt || 'No prompt yet'}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StoryEditor;