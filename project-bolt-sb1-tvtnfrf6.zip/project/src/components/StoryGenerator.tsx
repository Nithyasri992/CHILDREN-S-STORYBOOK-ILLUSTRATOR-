import React, { useState } from 'react';
import { Wand2, Sparkles, Heart, Star } from 'lucide-react';

interface StoryPage {
  id: string;
  pageNumber: number;
  storyText: string;
  illustrationPrompt: string;
}

interface StoryData {
  title: string;
  pages: StoryPage[];
  theme: string;
  mainCharacter: string;
  ageGroup: string;
}

interface StoryGeneratorProps {
  onStoryGenerated: (story: StoryData) => void;
  isGenerating: boolean;
  setIsGenerating: (generating: boolean) => void;
}

const themes = [
  { id: 'friendship', name: 'Friendship', icon: Heart, color: 'bg-pink-100 text-pink-600' },
  { id: 'adventure', name: 'Adventure', icon: Star, color: 'bg-blue-100 text-blue-600' },
  { id: 'courage', name: 'Courage', icon: Sparkles, color: 'bg-purple-100 text-purple-600' },
  { id: 'kindness', name: 'Kindness', icon: Heart, color: 'bg-green-100 text-green-600' },
];

const characters = [
  'Little Fox', 'Baby Elephant', 'Curious Cat', 'Brave Bear', 'Wise Owl', 'Playful Puppy'
];

const ageGroups = [
  { value: '3-4', label: '3-4 years' },
  { value: '4-6', label: '4-6 years' },
  { value: '6-8', label: '6-8 years' },
];

const StoryGenerator: React.FC<StoryGeneratorProps> = ({ onStoryGenerated, isGenerating, setIsGenerating }) => {
  const [selectedTheme, setSelectedTheme] = useState('friendship');
  const [selectedCharacter, setSelectedCharacter] = useState('Little Fox');
  const [selectedAgeGroup, setSelectedAgeGroup] = useState('4-6');
  const [customPrompt, setCustomPrompt] = useState('');

  const generateSampleStory = (): StoryData => {
    const samplePages: StoryPage[] = [
      {
        id: '1',
        pageNumber: 1,
        storyText: `Once upon a time, there was a little fox named Finn who lived in a cozy burrow. Finn was very shy and afraid to explore the big forest around his home.`,
        illustrationPrompt: 'A cute baby fox peeking out of a cozy burrow, surrounded by tall green trees, warm sunlight, in a soft watercolor children\'s book style.'
      },
      {
        id: '2',
        pageNumber: 2,
        storyText: `One sunny morning, Finn heard beautiful singing coming from the forest. His curiosity was stronger than his fear, so he took a tiny step outside.`,
        illustrationPrompt: 'A small fox with big curious eyes standing at the edge of his burrow, listening to musical notes floating in the air, forest in background, whimsical illustration style.'
      },
      {
        id: '3',
        pageNumber: 3,
        storyText: `As Finn walked deeper into the forest, he met a friendly rabbit who was singing. "Don't be afraid," said the rabbit. "The forest is full of friends!"`,
        illustrationPrompt: 'A little fox meeting a cheerful singing rabbit in a magical forest clearing, both animals smiling, warm colors, children\'s book illustration.'
      },
      {
        id: '4',
        pageNumber: 4,
        storyText: `The rabbit introduced Finn to other forest animals - a wise owl, a playful squirrel, and a gentle deer. They all welcomed Finn with warm smiles.`,
        illustrationPrompt: 'A group of friendly forest animals (fox, rabbit, owl, squirrel, deer) gathered in a circle, all smiling and welcoming, soft pastoral colors.'
      },
      {
        id: '5',
        pageNumber: 5,
        storyText: `From that day on, Finn wasn't afraid anymore. He had learned that being brave means taking small steps, and the world is full of wonderful friends waiting to meet you.`,
        illustrationPrompt: 'A confident little fox playing happily with his new animal friends in a sunny forest meadow, everyone laughing and playing together, joyful and bright.'
      }
    ];

    return {
      title: `${selectedCharacter} and the Magic of Friendship`,
      pages: samplePages,
      theme: selectedTheme,
      mainCharacter: selectedCharacter,
      ageGroup: selectedAgeGroup
    };
  };

  const handleGenerate = async () => {
    setIsGenerating(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const story = generateSampleStory();
    onStoryGenerated(story);
    setIsGenerating(false);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Create Your Story</h2>
        <p className="text-lg text-gray-600">Choose your story elements and let the magic begin!</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Story Parameters */}
        <div className="space-y-6">
          {/* Theme Selection */}
          <div>
            <label className="block text-lg font-semibold text-gray-700 mb-4">Story Theme</label>
            <div className="grid grid-cols-2 gap-3">
              {themes.map((theme) => {
                const Icon = theme.icon;
                return (
                  <button
                    key={theme.id}
                    onClick={() => setSelectedTheme(theme.id)}
                    className={`p-4 rounded-xl border-2 transition-all duration-200 ${
                      selectedTheme === theme.id
                        ? 'border-coral-400 bg-coral-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-full ${theme.color} flex items-center justify-center mx-auto mb-2`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="font-medium text-gray-700">{theme.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Character Selection */}
          <div>
            <label className="block text-lg font-semibold text-gray-700 mb-4">Main Character</label>
            <select
              value={selectedCharacter}
              onChange={(e) => setSelectedCharacter(e.target.value)}
              className="w-full p-3 border-2 border-gray-200 rounded-xl focus:border-coral-400 focus:outline-none"
            >
              {characters.map((character) => (
                <option key={character} value={character}>{character}</option>
              ))}
            </select>
          </div>

          {/* Age Group */}
          <div>
            <label className="block text-lg font-semibold text-gray-700 mb-4">Age Group</label>
            <div className="flex gap-3">
              {ageGroups.map((group) => (
                <button
                  key={group.value}
                  onClick={() => setSelectedAgeGroup(group.value)}
                  className={`px-4 py-2 rounded-full font-medium transition-all duration-200 ${
                    selectedAgeGroup === group.value
                      ? 'bg-mint-500 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {group.label}
                </button>
              ))}
            </div>
          </div>

          {/* Custom Prompt */}
          <div>
            <label className="block text-lg font-semibold text-gray-700 mb-4">Additional Ideas (Optional)</label>
            <textarea
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              placeholder="Any specific elements you'd like in the story..."
              className="w-full p-3 border-2 border-gray-200 rounded-xl focus:border-coral-400 focus:outline-none resize-none"
              rows={3}
            />
          </div>
        </div>

        {/* Preview/Generate */}
        <div className="bg-gradient-to-br from-coral-50 to-pink-50 p-6 rounded-2xl">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Story Preview</h3>
          <div className="bg-white p-4 rounded-xl mb-6">
            <h4 className="font-semibold text-coral-600 mb-2">Your Story Will Feature:</h4>
            <ul className="space-y-2 text-gray-700">
              <li>• <strong>Theme:</strong> {themes.find(t => t.id === selectedTheme)?.name}</li>
              <li>• <strong>Character:</strong> {selectedCharacter}</li>
              <li>• <strong>Age Group:</strong> {ageGroups.find(g => g.value === selectedAgeGroup)?.label}</li>
              <li>• <strong>Pages:</strong> 5 illustrated pages</li>
            </ul>
          </div>

          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full bg-gradient-to-r from-coral-500 to-pink-500 text-white py-4 rounded-xl font-semibold text-lg transition-all duration-200 transform hover:scale-105 hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
          >
            {isGenerating ? (
              <div className="flex items-center justify-center space-x-2">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                <span>Creating Magic...</span>
              </div>
            ) : (
              <div className="flex items-center justify-center space-x-2">
                <Wand2 className="w-5 h-5" />
                <span>Generate Story</span>
              </div>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default StoryGenerator;